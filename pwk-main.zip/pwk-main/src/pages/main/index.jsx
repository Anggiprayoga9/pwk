import { Hero, Navbar } from "../../components";

const Main = () => {
    return (
        <div>
            <Navbar />
            <Hero />
        </div>
    );
}

export default Main;